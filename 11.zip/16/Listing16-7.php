<?
if (!isset($PHP_AUTH_USER)) :

     header('WWW-Authenticate: Basic realm="Secret Family Recipes"');
     header('HTTP/1.0 401 Unauthorized');
     exit;

else :

     // connect to the mysql database
     mysql_connect ("host", "user", "password") 
				or die ("Can't connect to database!");
     mysql_select_db ("user_info") 
				or die ("Can't select database!");
     
     // query the user_authenticate table for authentication match
     $query = "select userid from user_authenticate where 
                                              username = '$PHP_AUTH_USER' and 
                                              password = '$PHP_AUTH_PW'";
 
    $result = mysql_query ($query);

     // if no match found, display authentication window
     if (mysql_numrows($result) != 1) :

          header('WWW-Authenticate: Basic realm="Secret Family Recipes"');
          header('HTTP/1.0 401 Unauthorized');
          exit;

     // else, retrieve user-Id
     else :
          $userid = mysql_result (user_authenticate, 0, $result);
     endif;

endif;

?>