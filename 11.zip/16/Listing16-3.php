<?

if ( (! isset ($PHP_AUTH_USER)) || (! isset ($PHP_AUTH_PW)) ):  
     header('WWW-Authenticate: Basic realm="Secret Family Recipes"');
     header('HTTP/1.0 401 Unauthorized');
     print "You are attempting to enter a restricted area. Authorization is required.";
     exit;
endif;  

?>