<?

if ( (! isset ($PHP_AUTH_USER)) || (! isset ($PHP_AUTH_PW)) ||
   ($PHP_AUTH_USER != 'secret') || ($PHP_AUTH_PW != 'recipes') ) :
  
     header('WWW-Authenticate: Basic realm="Secret Family Recipes"');
     header('HTTP/1.0 401 Unauthorized');
     print "You are attempting to enter a restricted area. Authorization is required.";
     exit;
endif;  

?>