<?

$file = "Listing16-5.txt";
$fp = fopen($file, "r");
$auth_file = fread ($fp, filesize($fp));
fclose($fp);

$authorized = 0;

// assign each line of file as array element 
$elements = explode ("\n", $auth_file);

foreach ($elements as $element) {

     list ($user, $pw) = split (":", $element);

     if (($user == $PHP_AUTH_USER) && ($pw == $PHP_AUTH_PW)) :
          $authorized = 1;
          break;     
     endif;

} // end foreach

if (! $authorized) :
          header('WWW-Authenticate: Basic realm="Secret Family Recipes"');
          header('HTTP/1.0 401 Unauthorized');
          print "You are attempting to enter a restricted area. Authorization is required.";
          exit;
else :
          print "Welcome to the family's secret recipe collection";
endif;
?>