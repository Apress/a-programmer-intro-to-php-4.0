<?
// assume that the variable $usr_id (containing a unique user ID)
// is stored in a cookie on the user's machine.

$id = session_id($usr_id);

// connect to the MySQL server and select user's database
@mysql_pconnect("localhost", "web", "4tf9zzzf") 
				or die("Could not connect to MySQL server!");
@mysql_select_db("users") 
				or die("Could not select company database!");

// select data from the MySQL table
$query = "SELECT page_data FROM user_info WHERE user_id= '$id'";
$result = mysql_query($query);
$user_data = mysql_result($result, 0, "page_data");

// decode the data
session_decode($user_data);

// output one of the regenerated session variables
print "BGCOLOR: $bgcolor";

?>
