<?

if (! isset($userid)) :
	$id = 15;
	setcookie ("userid", $id, time()+3600);
	print "A cookie containing your userID has been set on your machine. 
	Please refresh the page to retrieve your user information";
else:

@mysql_connect("localhost", "web", "4tf9zzzf") or die("Could not connect to MySQL server!");
@mysql_select_db("user") or die("Could not select user database!");

// declare query
$query = "SELECT * FROM users13 WHERE user_id = '$userid'";

// execute query
$result = mysql_query($query);

// If a match is found, display user information.
if (mysql_num_rows($result) == 1) :
    $row = mysql_fetch_array($result);
     print "Hi ".$row["fname"].",<br>";
     print "Your email address is ".$row["email"];
else:
   print "Invalid User ID!";
endif;
mysql_close();

endif;

?>