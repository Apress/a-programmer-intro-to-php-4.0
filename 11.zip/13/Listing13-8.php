<?
// MySQL implementation of session-handling functions

// mysql server host, username, and password values
$host = "localhost";
$user = "web";
$pswd = "4tf9zzzf";

// database and table names
$db = "users";
$session_table = "user_session_data";

// retrieve sess.gc_lifetime value from php.ini file
$sess_life = get_cfg_var("sess.gc_lifetime");

// Function: mysql_sess_open()
// mysql_sess_open() connects to the MySQL server
// and selects the database.

function mysql_sess_open($save_path, $session_name) {

     GLOBAL $host, $user, $pswd, $db;

     @mysql_connect($host, $user, $pswd) 
				or die("Can't connect to MySQL server!");

     @mysql_select_db($db) 
				or die("Can't select session database!");

} // end mysql_sess_open()

// Function: mysql_sess_close()
// mysql_sess_close() is not needed within the MySQL implementation. 
// *However*, it still must be defined.

function mysql_sess_close() {

	return true;

} // end mysql_sess_close()


// Function: mysql_sess_read()
// mysql_sess_read() reads the information from the MySQL database.

function mysql_sess_read($key) {

	GLOBAL $session_table;

	$query = "SELECT value FROM $session_table WHERE sess_key = '$key'";

	$result = mysql_query($query);

	if (list($value) = mysql_fetch_row($result)) :

		return $value;

	endif;

	return false;

} // end mysql_sess_read()

// Function: mysql_sess_write()
// mysql_sess_write() writes the information to the MySQL database.

function mysql_sess_write($key, $val) {

	GLOBAL $sess_life, $session_table;

	$expiration = time() + $sess_life;

	$query = "INSERT INTO $session_table VALUES('$key', '$expiration', '$value')";

	$result = mysql_query($query);

	// if the insert query failed because of the Primary key setting the sess_key column,
	// perform an update instead.

	if (! $result) :

		$query = "UPDATE $session_table 
				SET sess_expiration = '$expiration', sess_value='$value' 
				WHERE sess_key = '$key'";

		$result = mysql_query($result);

	endif;

} // end mysql_sess_write()


// Function: mysql_sess_destroy()
// mysql_sess_destroy() deletes all table rows having the session key = $sess_id

function mysql_sess_destroy($sess_id) {

	GLOBAL $session_table;

	$query = "DELETE FROM $session_table WHERE sess_key = '$sess_id'";

	$result = mysql_result($query);

	return $result;

} // end mysql_sess_destroy()


// Function: mysql_sess_gc()
// mysql_sess_gc() deletes all table rows 
// having an expiration < current time - session.gc_lifetime

function mysql_sess_gc($max_lifetime) {

	GLOBAL $session_table;

	$query = "DELETE FROM $session_table WHERE sess_expiration < " . time();
	$result = mysql_query($query);

	return mysql_affected_rows();

} // end mysql_sess_gc




session_set_save_handler("mysql_sess_open", "mysql_sess_close", "mysql_sess_read", 
					"mysql_sess_write", "mysql_sess_destroy", "mysql_sess_gc");

?>