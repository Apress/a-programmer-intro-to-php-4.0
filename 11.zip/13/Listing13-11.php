<?

// assume that the variable $usr_id (containing a unique user ID)
// is stored within a cookie on the users machine.

$usr_id = 15;

$id = session_id($usr_id);

@mysql_connect("", "root", "") or die("Could not connect to MySQL server!");
@mysql_select_db("book") or die("Could not select company database!");

$query = "SELECT fname FROM users13 WHERE user_id= '$usr_id'";
$result = mysql_query($query);
$user_data = mysql_result($result, 0, "fname");

session_decode($user_data);

print "BGCOLOR: $bgcolor";

mysql_close();

?>