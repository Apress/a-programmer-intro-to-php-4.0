<?
setcookie("phprecipes[uid]", "4139b31b7bab052", time()+3600);
setcookie("phprecipes[color]", "black", time()+3600);
setcookie("phprecipes[preference]", "english", time()+3600);

if (isset($phprecipes)) :
	while (list ($name, $value) = each ($phprecipes)) :
		echo "$name = $value<br>\n";
	endwhile;
endif;

?>