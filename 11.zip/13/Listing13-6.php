<?
// Initiate session and create a few session variables
session_register('bgcolor');
session_register('fontcolor');

// assume that the variable $usr_id (containing a unique user ID)
// is stored in a cookie on the user's machine.

// use session_id() to set the session ID to be the user's 
// unique user ID stored in the cookie and In the database
$id = session_id($usr_id);

// these variables could be set by the user via an HTML form
$bgcolor = "white";
$fontcolor = "blue";

// encode all session data into a single string
$usr_data = session_encode();

// connect to the MySQL server and select users database
@mysql_pconnect("localhost", "web", "4tf9zzzf") 
				or die("Could not connect to MySQL server!");
@mysql_select_db("users") 
				or die("Could not select user database!");

// update the user's page preferences
$query = "UPDATE user_info set page_data='$usr_data' WHERE user_id= '$id'";
$result = mysql_query($query) or die("Could not update user information!");
?>
