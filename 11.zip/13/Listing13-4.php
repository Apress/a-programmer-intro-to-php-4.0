<?
// build form
$form = "
<form action=\"Listing13-4.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
Your first name?:<br>
<input type=\"text\" name=\"fname\" size=\"20\" maxlength=\"20\" value=\"\"><br>
Your email?:<br>
<input type=\"text\" name=\"email\" size=\"20\" maxlength=\"35\" value=\"\"><br>
<input type=\"submit\" value=\"Register!\">
</form>
";
// If the form has not been displayed and the user does not have a cookie.
if ((! isset ($seenform)) && (! isset ($userid))) :

     print $form;

// If the form has been displayed but the user information has not yet been processed
elseif (isset ($seenform) && (! isset ($userid))) :

     srand ((double) microtime() * 1000000);
     $uniq_id = uniqid(rand());
     // connect to the MySQL server and select the users database
     @mysql_pconnect("localhost", "root", "") or die("Could not connect to MySQL server!");
     @mysql_select_db("book") or die("Could not select user database!");
	
     // declare and execute query
     $query = "INSERT INTO users13 VALUES('$uniq_id', '$fname', '$email')";
     $result = mysql_query($query) or die("Could not insert user information!");

     // set cookie "userid" to expire in one month.
     setcookie ("userid", $uniq_id, time()+2592000);

     print "Congratulations $fname! You are now registered! Your user information will be displayed uponon each subsequent visit to this page.";
// else if the cookie exists, use the userID to extract information from the users database
elseif (isset($userid)) :
     // connect to the MySQL server and select the users database
     @mysql_pconnect("localhost", "root", "") or die("Could not connect to MySQL server!");
     @mysql_select_db("book") or die("Could not select user database!");
	
     // declare and execute query
     $query = "SELECT * FROM users13 WHERE user_id = '$userid'";
     $result = mysql_query($query) or die("Could not extract user information!");
	
     $row = mysql_fetch_array($result);
     print "Hi ".$row["fname"].",<br>";
     print "Your email address is ".$row["email"];

endif;

?>