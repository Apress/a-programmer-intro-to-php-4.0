<?
include("Listing13-9.php");
if (! isset($$cookieName)) :

	// Set a new cookie
	setcookie($cookieName, $cookieValue, time()+$timeLimit);

	// Record the visitor information.
	recordUser();

endif;

?>

<html>

<head>
<title>Welcome to My Site!</title>
</head>

<body bgcolor="#c0c0c0" text="#000000" link="#808040" vlink="#808040" alink="#808040">
Welcome to my site. <a href = "visitors.php">Check out who else has recently visited</a>.
</body>

</html>