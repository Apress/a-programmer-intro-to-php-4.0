<html>
<?
include("sniffer.inc");
include("init.inc");
?>
<head>
<title>Most recent <?=$maxNumVisitors;?> visitors</title>

</head>

<body bgcolor="#ffffff" text="#000000" link="#808040" vlink="#808040" alink="#808040">

<?
viewStats();
?>

</body>
</html>