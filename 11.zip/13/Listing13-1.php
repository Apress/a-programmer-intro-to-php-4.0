<?
// If the variable $bgcolor exists
if (isset($bgcolor)) :
     setcookie("bgcolor", $bgcolor, time()+3600);
?>

<html>
<body bgcolor="<?=$bgcolor;?>">

<?
// else, $bgcolor is not set, therefore show the form
else :
?>
<body bgcolor="white">
<form action="<? print $PHP_SELF; ?>" method="post">
     What's your favorite background color?
     <select name="bgcolor">
          <option value="red">red
          <option value="blue">blue
          <option value="green">green
          <option value="black">black
     </select>
          <input type="submit" value="Set background color">
</form>

<?
endif;
?>
</body>
</html>