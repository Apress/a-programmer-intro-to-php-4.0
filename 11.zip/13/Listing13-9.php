<?
// file: init.inc
// purpose: initialization file for Visitor Logging project


// Connect to the MySQL Server

$host = "localhost";
$user = "root";
$pswd = "";

// database name

$database = "myTracker";

// polls table name

$visitors_table = "visitors";

@mysql_pconnect($host, $user, $pswd) or die("Couldn't connect to MySQL server!");

// Choose the database

@mysql_select_db($database) or die("Couldn't select $database database!");


// Number of recent visitors to display in table

$maxNumVisitors = "5";

// Cookie Name

$cookieName = "visitorLog";

// Cookie Value

$cookieValue="1";

// Timeframe between acknowledgement of subsequent visit by same user
// If $timeLimit is set to 0, every user visit to that page will be recorded
// regardless of the frequency. All other integer settings will be regarded as number SECONDS
// that must pass between visits in order to be recorded.

$timeLimit = 3600;

// How would you like the date-of-visit displayed in the browser?

$header_color = "#cbda74";
$table_color = "#000080";
$row_color = "#c0c0c0";
$font_color = "#000000";
$font_face = "Arial, Times New Roman, Verdana";
$font_size = "-1";

function recordUser() {

	GLOBAL $visitors_table, $HTTP_USER_AGENT, $REMOTE_ADDR, $REMOTE_HOST;

	if ($REMOTE_HOST == "") :

		$REMOTE_HOST = "localhost";

	endif;

	$timestamp = date("Y-m-d H:i:s");

	$query = "INSERT INTO $visitors_table VALUES('$HTTP_USER_AGENT', '$REMOTE_ADDR', '$REMOTE_HOST', '$timestamp')";

	$result = @mysql_query($query);

} // recordUser

function viewStats() {

	GLOBAL $visitors_table, $maxNumVisitors, $table_color, $header_color;
	GLOBAL $row_color, $font_color, $font_face, $font_size;

	$query = "SELECT browser, ip, host, TimeofVisit FROM $visitors_table ORDER BY TimeofVisit desc LIMIT 0, $maxNumVisitors";

	$result = mysql_query($query);

	print "<table cellpadding=\"2\" cellspacing=\"1\" width = \"700\" border = \"0\" bgcolor=\"$table_color\">";

	print "<tr bgcolor= \"$header_color\"><th>Browser</th><th>IP</th><th>Host</th><th>TimeofVisit</th></tr>";

	while($row = mysql_fetch_array($result)) :

		list ($browse_type, $browse_version) = browser_info ($row["browser"]);
		$op_sys = opsys_info ($row["browser"]);

		print "<tr bgcolor=\"$row_color\">";
		print "<td><font color=\"$font_color\" face=\"$font_face\" size=\"$font_size\">$browse_type $browse_version - $op_sys</font></td>";
		print "<td><font color=\"$font_color\" face=\"$font_face\" size=\"$font_size\">".$row["ip"]."</font></td>";
		print "<td><font color=\"$font_color\" face=\"$font_face\" size=\"$font_size\">".$row["host"]."</font></td>";
		print "<td><font color=\"$font_color\" face=\"$font_face\" size=\"$font_size\">";
		print $row["TimeofVisit"]."</font></td>";
		print "</tr>";
	

	endwhile;

	print "</table>";

} // viewStats


?>
