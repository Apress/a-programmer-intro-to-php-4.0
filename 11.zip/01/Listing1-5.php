<html>
<head>
<title>
<? 
print "Another PHP-enabled page";
$variable = "Hello World!";
?> 
</title></head>
<body>
<? print $variable; ?>
</body>
</html>