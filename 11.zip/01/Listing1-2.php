<html>
<head>
<title>Basic PHP/HTML integration</title>
</head>
<body>
<?
// Notice how HTML tags are included within the print statement. 
print "<h3>PHP/HTML integration is cool.</h3>";
?>
</body>
</html>