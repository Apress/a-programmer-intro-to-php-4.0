<title>PHP Recipes | <? print (date("F d, Y")); ?></title>
