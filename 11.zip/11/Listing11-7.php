<?php

// Connect to the ODBC datasource 'ContactDB'
$connect = odbc_connect("ContactDB","","") 
			or die("Couldn't connect to datasource."); 

// form query statement 

$query = "SELECT First_Name, Last_Name, Cell_Phone, Email FROM Contacts"; 

// prepare query statement 
$result = odbc_prepare($connect,$query); 

// execute query statement and display results
odbc_execute($result); 
odbc_result_all($result,"BGCOLOR='#c0c0c0' border=1"); 

// We're done with the query results, so free memory  
odbc_free_result($result); 

// close connection
odbc_close($connect); 

?> 
