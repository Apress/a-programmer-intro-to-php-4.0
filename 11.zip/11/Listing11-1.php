<?
@mysql_connect("localhost", "web", "ffttss") 
			or die("Could not connect to MySQL server!");
@mysql_select_db("company") 
			or die("Could not select products database!");

// select all rows in the products table
$query = "SELECT * FROM products";
$result = mysql_query($query);

$x = 0;
print "<table>\n";
print "<tr>\n<th>Product ID</th><th>Product Name</th><th>Product Price</th>\n</tr>\n";
while ($x < mysql_numrows($result)) :

	$id = mysql_result($result, $x, 'prod_id');
	$name = mysql_result($result, $x, 'prod_name');
	$price = mysql_result($result, $x, 'prod_price');

	print "<tr>\n";
	print "<td>$id</td>\n<td>$name</td>\n<td>$price</td>\n";
	print "</tr>\n";
     
	$x++;

endwhile;
print "</table>";
mysql_close();
?>