<?
$form = 
"<form action=\"Listing11-5.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
Keyword:<br>
<input type=\"text\" name=\"keyword\" size=\"20\" maxlength=\"20\" value=\"\"><br>
Search Focus:<br>
<select name=\"category\">
<option value=\"\">Choose a category:
<option value=\"cust_id\">Customer ID
<option value=\"cust_name\">Customer Name
<option value=\"cust_email\">Customer Email
</select><br>
<input type=\"submit\" value=\"search\">
</form>
";
// If the form has not been displayed, show it.
if ($seenform != "y") :
     print $form;
else :
     // connect to MySQL server and select database
     @mysql_connect("localhost", "web", "ffttss") 
				or die("Could not connect to MySQL server!");
     @mysql_select_db("company") 
				or die("Could not select company database!");

     // form and execute query statement
     $query = "SELECT cust_id, cust_name, cust_email 
			FROM customers WHERE $category = '$keyword'";
     $result = mysql_query($query);

     // If no matches found, display message and redisplay form
     if (mysql_num_rows($result) == 0) :
          print "Sorry, but no matches were found. Please try your search again:";
          print $form;
     // matches found, therefore format and display results
     else :
          // format and display returned row values.
          list($id, $name, $email) = mysql_fetch_row($result);
          print "<h3>Customer Information:</h3>";
          print "<b>Name:</b> $name <br>";
          print "<b>Identification #:</b> $id <br>";
          print "<b>Email:</b> <a href=\"mailto:$email\">$email</a> <br>";
   
          print "<h3>Order History:</h3>";
          // form and execute 'orders' query
          $query = "SELECT order_id, prod_id, quantity FROM orders WHERE cust_id = '$id' 
                          ORDER BY quantity DESC";
          $result = mysql_query($query);

          print "<table border = 1>";
          print "<tr><th>Order ID</th><th>Product ID</th><th>Quantity</th></tr>";
          // format and display returned row values.
          while (list($order_id, $prod_id, $quantity) = mysql_fetch_row($result)) :
               print "<tr>";
               print "<td>$order_id</td><td>$prod_id</td><td>$quantity</td>";
               print "</tr>";	
          endwhile;
          print "</table>";
     endif;
endif;
?>