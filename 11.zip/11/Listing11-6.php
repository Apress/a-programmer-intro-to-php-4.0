<?
// connect to MySQL server and select database
@mysql_connect("localhost", "web", "ffttss") 
			or die("Could not connect to MySQL server!");
@mysql_select_db("company") 
			or die("Could not select company database!");

// If the $key variable is not set, default to 'quantity'
if (! isset($key)) :
     $key = "quantity";
endif;
// create and execute query. Any retrieved data is sorted in descending order
$query = "SELECT order_id, cust_id, prod_id, quantity FROM orders ORDER BY $key DESC";
$result = mysql_query($query);
// create table header 
print "<table border = 1>";
print "<tr>
<th><a href=\"Listing11-6.php?key=order_id\">Order ID</a></th>
<th><a href=\"Listing11-6.php?key=cust_id\">Customer ID</a></th>
<th><a href=\"Listing11-6.php?key=prod_id\">Product ID</a></th>
<th><a href=\"Listing11-6.php?key=quantity\">Quantity</a></th></tr>";
// format and display each row value
while (list($order_id, $cust_id, $prod_id, $quantity) = mysql_fetch_row($result)) :
     print "<tr>";
     print "<td>$order_id</td><td>$cust_id</td><td>$prod_id</td><td>$quantity</td>";
     print "</tr>";	
endwhile;
// close table
print "</table>";
?>