<html>
<?
INCLUDE("init.inc");
?>
<head>
<title><?=$title;?></title>
</head>

<body bgcolor="#ffffff" text="#000000" link="#808040" vlink="#808040" alink="#808040">

<?
if (! $seenform) :
?>

<form action="add_bookmark.php" method="post">
<input type="hidden" name="seenform" value="y">

Category:<br>
<select name="category">
<option value="">Choose a category:
<?
while (list($key, $value) = each($categories)) :

     print "<option value=\"$key\">$value";

endwhile;
?>
</select><br>

Site Name:<br>
<input type="text" name="site_name" size="15" maxlength="30" value=""><br>

URL: (do <i>not</i> include "http://"!)<br>
<input type="text" name="url" size="35" maxlength="50" value=""><br>

Description:<br>
<textarea name="description" rows="4" cols="30"></textarea><br>
<input type="submit" value="submit">
</form>
<?
else :

     add_bookmark($category, $site_name, $url, $description);

     print "<h4>Your bookmark has been added to the repository. <a href=\"Listing11-11.php\">Click here</a> to return to the index.</h4>";

endif;
?>