<?
// file: init.inc
// purpose: provides global variables for use in bookmark project

// Default page title
$title = "My Bookmark Repository";

// Background color
$bg_color = "white";

// Posting date
$post_date = date("Ymd");

// bookmark categories
$categories = array(
                    "computers",
                    "entertainment",
                    "dining",
                    "lifestyle",
                    "government",
                    "travel");

// MySQL Server Information
$host = "localhost";
$user = "root";
$pswd = "";

// database name
$database = "book";

// bookmark table name
$bookmark_table = "bookmarks";

// Table cell color
$cell_color = "#c0c0c0";

// Connect to the MySQL Server
@mysql_pconnect($host, $user, $pswd) or die("Couldn't connect to MySQL server!");

// Select the database
@mysql_select_db($database) or die("Couldn't select $database database!");

// function: add_bookmark()
// purpose: Add new bookmark to bookmark table.

function add_bookmark ($category, $site_name, $url, $description) {
     GLOBAL $bookmark_table, $post_date;

     $query = "INSERT INTO $bookmark_table 
                    VALUES(\"$category\", \"$site_name\", \"$url\", \"$post_date\", \"$description\")";

     $result = @mysql_query($query) or die("Couldn't insert bookmark information!");

} // add_bookmark

// function: view_bookmark()
// purpose: Extract all bookmarks having category of $category from bookmark table.

function view_bookmark ($category) {

     GLOBAL $bookmark_table, $cell_color, $categories;

     $query = "SELECT site_name, url, DATE_FORMAT(date_added,'%m-%d-%Y') AS date_added, description 
                    FROM $bookmark_table WHERE category = $category 
                    ORDER BY date_added DESC";

     $result = @mysql_query($query);

     print "<div align=\"center\"><table cellpadding=\"2\" cellspacing=\"1\" border = \"0\" width = \"600\">";

     print "<tr><td bgcolor=\"$cell_color\"><b>Category: $categories[$category]</b></td></tr>";

     if (mysql_numrows($result) > 0) :

          while ($row = mysql_fetch_array($result)) :

               print "<tr><td>";
               print "<b>".$row["site_name"]."</b> | Posted: ".$row["date_added"]."<br>";
               print "</td></tr>";

               print "<tr><td>";
               print "<a href = \"http://".$row["url"]."\">http://".$row["url"]."</a><br>";
               print "</td></tr>";

               print "<tr><td valign=\"top\">";
               print $row["description"]."<br>";
               print "</td></tr>";

               print "<tr><td><hr></td></tr>";

          endwhile;

     else :

          print "<tr><td>There are currently no bookmarks falling under this category. 
               Why don't you <a href=\"add_bookmark.php\">add one</a>?</td></tr>";

     endif;

     print "</table><a href=\"Listing11-11.php\">Return to index</a> |";
     print "<a href=\"add_bookmark.php\">Add a bookmark</a></div>";

} // view_bookmark

?>