<?
@mysql_connect("localhost", "web", "ffttss") 
			or die("Could not connect to MySQL server!");
@mysql_select_db("company") 
			or die("Could not select products database!");

$query = "SELECT * FROM products";
$result = mysql_query($query);

print "<table>\n";
print "<tr>\n<th>Product ID</th><th>Product Name</th><th>Product Price</th>\n</tr>\n";
while ($row = mysql_fetch_array($result)) :
	print "<tr>\n";
	print "<td>".$row["prod_id"]."</td>\n<td>".$row["prod_name"]."</td>\n<td>".$row["prod_price"]."</td>\n";
	print "</tr>\n";
endwhile;
print "</table>";
mysql_close();
?>