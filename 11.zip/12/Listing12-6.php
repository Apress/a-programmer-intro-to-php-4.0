<?
// Include the template class
include("template.class");

// Assign a few variables
$page_title = "Welcome to your homepage!";
$bg_color = "white";
$user_name = "Chef Jacques";

// Instantiate a new object
$template = new template;

// Register the file "homepage.html", assigning it the pseudonym "home"
$template->register_file("home", "homepage.html");

// Register a few variables
$template->register_variables("home", "page_title,bg_color,user_name");
$template->file_parser("home");
// output the file to the browser
$template->print_file("home");

?>