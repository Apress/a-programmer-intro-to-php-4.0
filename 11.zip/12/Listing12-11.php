<?
// class.template.inc


class template {

	VAR $files = array();
	VAR $variables = array();
	VAR $sql = array();
	VAR $opening_escape = '{';
	VAR $closing_escape = '}';
	VAR $sql_delimiter = "|";

	VAR $host = "localhost";
	VAR $user = "root";
	VAR $pswd = "";
	VAR $db = "book";

	VAR $address_table = "addressbook";





	function register_file($file_id, $file_name) {

		$fh = fopen($file_name, "r") or die("Couldn't open $file_name!");

		$file_contents = fread($fh, filesize($file_name));

		$this->files[$file_id] = $file_contents;

		fclose($fh);

	} // end register_file;





	function register_variables($file_id, $variable_name) {

		// attempt to create array from passed in variable names

		$input_variables = explode(",", $variable_name);

		// assign variable name to next position in $file_id array

		while (list(,$value) = each($input_variables)) :

				$this->variables[$file_id][] = $value;				

		endwhile;			

	} // end register_variables






	// This function is called when the addressbook must be retrieved

	function address_sql($file_id, $variable_name, $letter) {

		mysql_connect($this->host, $this->user, $this->pswd) or die("Couldn't connect to MySQL server!");
		
		mysql_select_db($this->db) or die("Couldn't select MySQL database!");

		$query = "SELECT last_name, first_name, tel, email 
					FROM $this->address_table WHERE last_name LIKE '$letter%'";
		
		 $result = mysql_query($query);

		$fh = fopen("$variable_name", "r");
		
		$file_contents = fread($fh, filesize("rows.addresses") );

		while ($row = mysql_fetch_array($result)) :

			$new_row = $file_contents;

			$new_row = str_replace($this->opening_escape."last_name".$this->closing_escape,
										$row["last_name"],
										$new_row);

			$new_row = str_replace($this->opening_escape."first_name".$this->closing_escape,
										$row["first_name"],
										$new_row);

			$new_row = str_replace($this->opening_escape."telephone".$this->closing_escape,
										$row["tel"],
										$new_row);

			$new_row = str_replace($this->opening_escape."email".$this->closing_escape,
										$row["email"],
										$new_row);

			$complete_table .= $new_row;

		endwhile;

		$sql_array_key = $variable_name;

		$this->sql[$sql_array_key] = $complete_table;

		// add the key to the variables array for later lookup
		$this->variables[$file_id][] = $variable_name;		

		fclose($fh);

	} // end sql_address



	function file_parser($file_id) {

		$varcount = count($this->variables[$file_id]);

		$keys = array_keys($this->files);

		if ( (in_array($file_id, $keys)) && ($varcount > 0) ) :

			$x = 0;

			while ($x < sizeof($this->variables[$file_id])) :

				$string = $this->variables[$file_id][$x];
				GLOBAL $$string;

				$needle = $this->opening_escape.$string.$this->closing_escape;

				// Verify whether the {string} is meant for variable replacement or SQL processing

				if (eregi("rows", $this->variables[$file_id][$x])) :

					$sql_replacement = $this->sql[$this->variables[$file_id][$x]];

					$this->files[$file_id] = str_replace(
													$needle,	  								// needle
													$sql_replacement,						// string
													$this->files[$file_id]);						// haystack					

				else :

					$this->files[$file_id] = str_replace(
													$needle,	  								// needle
													$$string, 									// string
													$this->files[$file_id]);						// haystack

				endif;

				$x++;

			endwhile;

		endif;

	} // end file_parser


	function print_file($file_id) {

		print $this->files[$file_id];

	}


} // END templater class


?>