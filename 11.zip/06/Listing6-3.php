<?

class Vehicle {
	var $model;
	var $current_speed;

	function setSpeed($mph) {
		$this->current_speed = $mph;
	}

	function getSpeed() {
		return $this->current_speed;
	}

} // end class Vehicle

class Auto extends Vehicle {
	var $fuel_type;

	function setFuelType($fuel) {
		$this->fuel_type = $fuel;
	}

	function getFuelType() {
		return $this->fuel_type;
	}

} // end Auto extends Vehicle

class Airplane extends Vehicle {
	var $wingspan;
	
	function setWingSpan($wingspan) {
		$this->wingspan = $wingspan;
	}

	function getWingSpan() {
		return $this->wingspan;
	}
	
} // end Airplane extends Vehicle

?>