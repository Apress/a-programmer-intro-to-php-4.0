<?

class Vehicle {
     var $model;
     var $current_speed;
}

class Airplane extends Vehicle {
     var $wingspan;
}

$a_class = "Airplane";

$attribs = get_class_vars($a_class); 
// $attribs = array ( "wingspan", "model", "current_speed")

?>