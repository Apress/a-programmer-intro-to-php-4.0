    <?
 class Vehicle {
 var $motor; 
     }

     class Land extends Vehicle {
          var $fourWheel;
          function setFourWheelDrive() {
               $this->fourWeel = 1;
          }
     }

     //  create object named $car
     $car = new Land;

     // if method "fourWheelDrive" is a part of classes "Land" or "Vehicle",
     // then the call to method_exists will return true; Otherwise false will be returned.
     // Therefore, in this case, method_exists() will return true.

     if (method_exists($car, "setfourWheelDrive")) :
          print "This car is equipped with 4-wheel drive";
     else :
          print "This car is not equipped with 4-wheel drive";
     endif;
?>
