<?

class Page { 
     var $bgcolor;
     var $textcolor;	

     function Page() { 
          // Determine the number of arguments passed in, and create correct method name
          $name = "Page".func_num_args(); 
          // Call $name with correct number of arguments passed in
          if ( func_num_args() == 0 ) : 
               $this->$name(); 
          else :
               $this->$name(func_get_arg(0)); 
          endif; 
     } 

     function Page0() { 
          $this->bgcolor = "white";
          $this->textcolor = "black";	
          print "Created default page";
     } 

     function Page1($bgcolor) { 
          $this->bgcolor = $bgcolor;
          $this->textcolor = "black";			
          print "Created custom page";
     } 
} 
$html_page = new Page("red");

?>