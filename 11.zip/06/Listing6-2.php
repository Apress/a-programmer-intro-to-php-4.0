<?
class Webpage {
	var $bgcolor;

	function Webpage($color) {
		$this->bgcolor = $color;
	}
}

// call the Webpage constructor
$page = new Webpage("brown");
?>