<?

class Vehicle {
     var $wheels;
}

class Land extends Vehicle {
     var $engine;
}

class car extends Land {
     var $doors;

     function car($doors, $eng, $wheels) {
          $this->doors = $doors;
          $this->engine = $eng;
          $this->wheels = $wheels;
     }

     function get_wheels() {
          return $this->wheels;
     }

}

$toyota = new car(2,400,4);

$vars = get_object_vars($toyota);

while (list($key, $value) = each($vars)) :

	print "$key ==> $value <br>";

endwhile;
// displays:// doors ==> 2
// engine ==> 400
// wheels ==> 2

?>