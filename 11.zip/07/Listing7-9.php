<?
// script: simple access counter
// purpose: uses a file to keep track of visitor count

$access = "hits.txt";
$visits = @file($access);
$current_visitors = $visits[0];
++$current_visitors;
$fh = fopen($access, "w");

@fwrite($fh, $current_visitors);
fclose($fh);

?>