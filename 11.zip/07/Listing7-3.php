<?
$fh = fopen("science.html", "r");

while (!feof($fh)) :
	print fgetss($fh, 2048);
endwhile;

fclose($fh);
?>