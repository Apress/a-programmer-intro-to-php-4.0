<?
$fh = fopen("science.html", "r");
$allowable = "<br>";
while (!feof($fh)) :
	print fgetss($fh, 2048, $allowable);
endwhile;
fclose($fh);
?>