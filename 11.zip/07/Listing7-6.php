<?
function getthehost($host,$path) { 
     // open the host
     $fp = fsockopen($host, 80, &$errno, &$errstr, 30); 
     // take control of server timeout
     socket_set_blocking($fp, 1);
     // send the appropriate headers
     fputs($fp,"GET $path HTTP/1.1\r\n"); 
     fputs($fp,"Host: $host\r\n\r\n"); 
     $x = 1;
     // grab a bunch of headers
     while($x < 10) : 
          $headers = fgets($fp,4096); 
		print $headers;
          $x++;
     endwhile;

     // close the filepointer.
     fclose($fp); 
} 

getthehost("www.apress.com", "/");
?>