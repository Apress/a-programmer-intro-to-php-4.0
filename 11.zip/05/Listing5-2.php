<?

$vocab = array("Socrates","Aristophanes", "Plato", "Aeschylus", "Thesmophoriazusae");

function compare_length($str1, $str2) {

$length1 = strlen($str1);
$length2 = strlen($str2);

if ($length1 == $length2) :

	return 0;

elseif ($length1 < $length2) :

	return -1;

else :

	return 1;

endif;

}


usort($vocab, "compare_length");

while (list ($key, $val) = each ($vocab)) { 

	echo "$val<br>"; 

} 


?>