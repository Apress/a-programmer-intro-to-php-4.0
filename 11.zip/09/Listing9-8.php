<?
// file: index.php
// purpose: Home page of PHPRecipes
// date: August 23, 2000
// Include the header
include ("header.tpl");
// Include the index body
include ("index_body.tpl");
// Include the footer
include ("footer.tpl");
?>