<?
// file: static.php
// purpose: display various requested static pages.
// IMPORTANT: It is assumed that "site_init.tpl" and all of the 
// static files are located in the same directory.

// load functions and site variables
include("site_init.tpl");

// display the page header
show_header($site_name);

// display the requested content
include("$content.html");

// display the page footer
show_footer();

?>