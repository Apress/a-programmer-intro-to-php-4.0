<?
// Include site initialization information
include("site_init.tpl");

// display the header
show_header($site_name);
?>
This is some body information
<?
// display the footer
show_footer();
?>