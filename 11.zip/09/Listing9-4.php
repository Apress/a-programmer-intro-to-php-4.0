<? require ('init.tpl'); ?>
<html>
<head>
<title><? print $site_title; ?></title>
</head>
<body>
<? print "Welcome to $site_title. For questions, contact <a href = \"mailto:$contact_email\">$contact_name</a>."; ?>
</body>
</html>