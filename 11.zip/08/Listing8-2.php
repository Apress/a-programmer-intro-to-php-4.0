<?
$meta_tags = get_meta_tags("example.html");

// $meta_tags will return an array containing the following information:

// $meta_tags["keywords"] = "gourmet, PHP, food, code, recipes, chef, programming, Web";
// $meta_tags["description"] = "PHP Recipes provides savvy readers with the latest in PHP programming and gourmet cuisine";
// $meta_tags["author"] = "WJ Gilmore";

?>