<?
$url = "http://www.apress.com";

// break $url down into three distinct pieces: "http://www", "apress", and "com"
$www_url = ereg("^(http://www)\.([[:alnum:]]+)\.([[:alnum:]]+)", $url, $regs);

if ($www_url) :          // if $www_url is a valid URL
     echo $regs[0];     // outputs the entire string "http://www.apress.com"
     print "<br>";
     echo $regs[1];     // outputs "http://www"
     print "<br>";
     echo $regs[2];     // outputs "apress"
     print "<br>";
     echo $regs[3];     // outputs "com"
endif;
?>