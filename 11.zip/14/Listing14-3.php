<?

class XMLHTML {

	VAR $xmlparser;
	VAR $tagcolor = "#800000";
	VAR $datacolor = "#0000ff";

	function XMLHTML() {

		$this->xmlparser = xml_parser_create();
		xml_set_object($this->xmlparser, &$this);
		xml_set_element_handler($this->xmlparser, "startTag", "endTag");
		xml_set_character_data_handler($this->xmlparser, "characterData");

	}

// This function is responsible for handling all starting element tags.

function startTag($parser, $tagname, $attributes) {
     GLOBAL $tagcolor;
     print "<font size=\"-2\" color=\"$this->tagcolor\" face=\"arial, verdana\">&lt;$tagname&gt;</font> <br>";
}

// This function is responsible for handling all character data.

function characterData($parser, $characterData) {
     GLOBAL $datacolor;
     print "<font size=\"-2\" color=\"$this->datacolor\" face=\"arial,  
               verdana\">&nbsp;&nbsp;&nbsp;$characterData</font> <br>";
}

// This function is responsible for handling all ending element tags.

function endTag($parser, $tagname) {
	GLOBAL $tagcolor;
	print "<font size=\"-2\" color=\"$this->tagcolor\" face=\"arial, verdana\">&lt;/$tagname&gt;</font> <br>";
}

function parse($fp) {

	// xml_parse($this->xmlparser,$data); 

	// Parse the XML file
	while ( $line = fread($fp, 4096) ) :
     	
		// If something goes wrong, stop and print an error message.

	     if ( ! xml_parse($this->xmlparser, $line, feof($fp))) :
      		die(sprintf("XML error: %s at line %d", 
               	xml_error_string(xml_get_error_code($this->xmlparser)), 
               	xml_get_current_line_number($this->xmlparser))); 
	     endif;

	endwhile;

}

} // end class

// Open the XML file for parsing
$xml_file = "bookmarks.xml";

$fp = fopen($xml_file, "r");

$xml_parser = new XMLHTML;

$xml_parser->parse($fp);


?>