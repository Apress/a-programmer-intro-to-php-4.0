<?
// Connect to the MySQL server
$host = "localhost";
$user = "root";
$pswd = "";
$db = "book";
$address_table = "addressbook";

mysql_connect($host, $user, $pswd) or die("Couldn't connect to MySQL server!");
mysql_select_db($db) or die("Couldn't select database!");

// Query the company database for all 'addresses' rows
$query = "SELECT * FROM $address_table ORDER BY last_name";
$result = mysql_query($query);

// Instantiate a new COM object. In this case, one pointing to the MS Word application
$word=new COM("word.application") or die("Couldn't start Word!"); 

// Make MS Word the active Window
$word->visible =1; 

// Declare a new, empty document.
$word->Documents->Add(); 

// Cycle through each address table row.
while($row = mysql_fetch_array($result)) :
     $last_name = $row["last_name"];
     $first_name = $row["first_name"];
     $tel = $row["tel"];
     $email = $row["email"];

     // Output table data to the open Word document.

     $word->Selection->Typetext("$last_name, $first_name\n"); 
     $word->Selection->Typetext("tel. $tel\n");
     $word->Selection->Typetext("email. $email:\n"); 

endwhile;

// Prompt the user for a document name
$word->Documents[1]->Save;

// Quit the MS Word Application
$word->Quit();
?>
