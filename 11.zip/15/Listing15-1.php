<?
// retrieve browser information
$browser = get_browser();

// typeset $browser to an array
$browser = (array) $browser;

while (list ($key, $value) = each ($browser)) :

     // clarify which of the browser elements are empty
     if ($value == "") :
          $value = 0;
     endif;

     print "$key : $value <br>";

endwhile;
?>