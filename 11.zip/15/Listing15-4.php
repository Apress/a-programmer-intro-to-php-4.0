<html>
<head>
<title>Listing 15-4</title>
<SCRIPT language="Javascript">
<!--
     // declare a new Javascript variable
     var popWindow;
     // declare a new function, newWindow
     function newWindow(winID) {
          // declare variable winURL, setting it to the name of the PHP file and accompanying data.
          var  winURL = "Listing15-5.php?winID=" + winID;
          // If the popup window does not exist, or it is currently closed, open it.
          if (! popWindow || popWindow.closed) {
               // open new window having width of 200 pixels, height of 300 pixels, positioned
               // 150 pixels left of the linking window, and 100 pixels from the top of the linking  window.
               popWindow = window.open(winURL, 'popWindow', 
                                                            'dependent,width=200,height=300,left=150,top=100'); 
               }
               // If the popup window is already open, make it active and update its location to winURL.
          else {
               popWindow.focus();
               popWindow.location = winURL;
          }
     }
//-->
</SCRIPT>
</head>
<body bgcolor="#ffffff" text="#000000" link="#808040" vlink="#808040" alink="#808040">

<a href="#" onClick="newWindow(1);">Contact Us</a><br>
<a href="#" onClick="newWindow(2);">Driving Directions</a><br>
<a href="#" onClick="newWindow(3);">Weather Report</a><br>

</body>
</html>