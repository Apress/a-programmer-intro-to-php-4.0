<?
$browser = get_browser();

// typeset $browser to an array
$browser = (array) $browser;

if ($browser["javascript"] == 1) :
     print "Javascript enabled!";
else :
     print "No javascript allowed!";
endif;
?>