<html>
<head>
<title>Popup Window Fun</title>
</head>

<body bgcolor="#ffffff" text="#000000" link="black" vlink="gray" alink="#808040">

     <table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
               <td>
               <?
               // Include file specified by input parameter
               INCLUDE("$winID.inc");
               ?>
               </td>
          </tr>
          <tr>
               <td>
               <a href="#" onClick="parent.self.close();">close window</a>
               </td>
          </tr>
     </table>

</body>
</html>