<?
// Instantiate a new object pointing to the MS Word application
$word=new COM("word.application") or die("Couldn't start Word!"); 

// Make MS Word the active window.
$word->visible =1; 

// Create a new document
$word->Documents->Add(); 

// Insert some text into the document
$word->Selection->Typetext("php's com functionality is cool\n"); 

// Set the default document format to Text
$ok = com_set($word->Application, DefaultSaveFormat, "Text");

// Prompt the user to name and save the document.
// Notice that the default document format is Text!
$word->Documents[1]->Save;

// Quit MS Word
$word->Quit();
?>