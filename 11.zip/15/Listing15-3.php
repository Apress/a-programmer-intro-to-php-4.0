<html> 
<head> 
<title>Browser Information</title> 
</head> 
<body> 
<script language="Javascript1.2"> 
<!--// 

document.write('<form method=POST action ="<? echo $PHP_SELF; ?>">');
document.write('<input type=hidden name=version value=' + navigator.appVersion + '>'); 
document.write('<input type=hidden name=type value=' + navigator.appName + '>'); 
document.write('<input type=hidden name=screenWidth value=' + screen.width + '>'); 
document.write('<input type=hidden name=screenHeight value=' + screen.height + '>'); 
document.write('<input type=hidden name=browserHeight value=' + window.innerWidth + '>'); 
document.write('<input type=hidden name=browserWidth value=' + window.innerHeight + '>'); 
//--> 
</script> 
<input type="submit" value="Get browser information"><p> 
</form>

<? 
//if (isset($screenWidth)) :
     echo "<b>Browser:</b> $type Version: $version<br>"; 
     echo "<b>Screen Resolution:</b> $screenWidth x $screenHeight pixels.<br>"; 
     if ($browserWidth != 0) : 
          echo "<b>Browser resolution:</b> $browserWidth x $browserHeight pixels.";
     else : 
          echo "No javascript browser resolution support for Internet Explorer"; 
     endif; 
//endif;
?> 
</body> 
</html>