<html>
<head>
<title>Listing 10-5</title>
</head>
<body bgcolor="#ffffff" text="#000000" link="#cbda74" vlink="#808040" alink="#808040">

<?
// all double quotations in $form must be escaped, otherwise a parse error will occur
$form = "
<form action=\"listing10-5.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
<b>Send us your comments!</b><br>
Your Name:<br>
<input type=\"text\" name=\"name\" size=\"20\" maxlength=\"20\" value=\"\"><br>
Your Email:<br>
<input type=\"text\" name=\"email\" size=\"20\" maxlength=\"40\" value=\"\"><br>
Your Comments:<br>
<textarea name=\"comments\" rows=\"3\" cols=\"30\"></textarea><br>
<input type=\"submit\" value=\"submit!\">
</form>
";

// If we haven't already seen the form ($seenform passed by hidden form value), show the form.
if ($seenform != "y") :
     print "$form";
else :
     // change $recipient to be the recipient of the form information
     $recipient = "yourname@youremail.com";
     // email subject
     $subject = "User Comments ($name)";
     // extra email headers
     $headers = "From: $email";
     // send the email or produce an error
     mail($recipient, $subject, $comments, $headers) or die("Could not send email!");
     // send the user an appropriate message
     print "Thank you $name for taking a moment to send us your comments!";

endif;
?>
</body>
</html>