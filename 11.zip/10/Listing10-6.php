<html>
<head>
<title>Listing 10-5</title>
</head>
<body bgcolor="#ffffff" text="#000000" link="#cbda74" vlink="#808040" alink="#808040">
<?

$form = "
<form action=\"Listing10-6.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
<b>Receive information about our site!</b><br>
Your Email:<br>
<input type=\"text\" name=\"email\" size=\"20\" maxlength=\"40\" value=\"\"><br>
<input type=\"checkbox\" name=\"information[site]\" value=\"y\">Site Architecture<br>
<input type=\"checkbox\" name=\"information[team]\" value=\"y\">Development Team<br>
<input type=\"checkbox\" name=\"information[events]\" value=\"y\">Upcoming Events<br>
<input type=\"submit\" value=\"send it to me!\">
</form>";

if ($seenform != "y") :
     print "$form";
else :
     $headers = "From: devteam@yoursite.com";
     // cycle through each array key/value element
     while ( list($key, $val) = each ($information) ) :
          // verify if the current value is "y"
          if ($val == "y") :
               
               // create filename that corresponds with current key
               $filename = "$key.txt";
               $subject = "Requested $key information"; 
               
               // open the filename
               $fd = fopen ($filename, "r"); 
               // read the entire file into a variable
               $contents = fread ($fd, filesize ($filename)); 
               
               // send email.
               mail($email, $subject, $contents, $headers) or die("Can't send email!");;
               fclose($fd);
          endif;
     endwhile;
     // Notify user of success
     print sizeof($information)." informational newsletters have been sent to $email!";
endif;
?>
</body>
</html>