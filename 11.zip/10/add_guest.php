<html>
<?
INCLUDE("init.inc");
?>
<head>
<title><?=$page_title;?></title>
</head>

<body bgcolor="#ffffff" text="#000000" link="#808040" vlink="#808040" alink="#808040">

<?
if (! $seenform) :
?>

<form action="add_guest.php" method="post">
<input type="hidden" name="seenform" value="y">

Name:<br>
<input type="text" name="name" size="15" maxlength="30" value=""><br>

Email:<br>
<input type="text" name="email" size="15" maxlength="35" value=""><br>

Comment:<br>
<textarea name="comment" rows="3" cols="40"></textarea><br>
<input type="submit" value="submit">
</form>
<?

else :

	add_guest($name, $email, $comment);

	print "<h3>Your comments have been added to the guestbook. <a href=\"index.php\">Click here</a> to return to the index.</h3>";

endif;

?>