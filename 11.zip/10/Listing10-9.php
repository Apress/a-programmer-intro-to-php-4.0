<?
if ($site != "") :
	header("Location: http://$site");
	exit;
else :
?>

<html>
<head>
<title>Listing 10-9</title>
</head>
<body bgcolor="#ffffff" text="#000000" link="#cbda74" vlink="#808040" alink="#808040">
<?
$favsites = array ("www.k10k.com",
                             "www.yahoo.com",
                             "www.drudgereport.com",
                             "www.phprecipes.com",
                             "www.frogdesign.com");

// now build the form
?>
<form action = "Listing10-9.php" method="post">
<select name="site">
<option value = "">Choose a site:
<?
$x = 0;

while ( $x < sizeof ($favsites) ) :
          print "<option value='$favsites[$x]'>$favsites[$x]";
          $x++;
endwhile;
?>
</select>
<input type="submit" value="go!">
</form>
<?
endif;
?>