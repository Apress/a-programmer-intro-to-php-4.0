<html>
<head>
<title>Listing 10-7</title>
</head>
<body bgcolor="#ffffff" text="#000000" link="#cbda74" vlink="#808040" alink="#808040">
<?
// create the form
$form = "
<form action=\"Listing10-7.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
<b>Give us your personal info!</b><br>
Your Name:<br> 
<input type=\"text\" name=\"name\" size=\"20\" maxlength=\"20\" value=\"\"><br>
Your Email:<br> 
<input type=\"text\" name=\"email\" size=\"20\" maxlength=\"20\" value=\"\"><br>
Your Preferred Language:<br>
<select name=\"language\">
<option value=\"\">Choose a language:
<option value=\"English\">English
<option value=\"Spanish\">Spanish
<option value=\"Italian\">Italian
<option value=\"French\">French
<option value=\"Japanese\">Japanese
<option value=\"newyork\">NewYork-ese
</select><br>
Your Occupation:<br>
<select name=\"job\">
<option value=\"\">What do you do?:
<option value=\"student\">Student
<option value=\"programmer\">Programmer
<option value=\"manager\">Project Manager
<option value=\"slacker\">Slacker
<option value=\"chef\">Gourmet Chef
</select><br>
<input type=\"submit\" value=\"submit!\">
</form>";

// has the form already been filled in?
if ($seenform != "y") :
     print "$form";
else :
     $fd = fopen("user_information.txt", "a");

     // make sure user has not entered a vertical bar in the input
     $name = str_replace("|", "", $name);
     $email = str_replace("|", "", $email);

     // assemble user information
     $user_row = $name."|".$email."|".$language."|".$job."\n";
     fwrite($fd, $user_row) or die("Could not write to file!");
     fclose($fd);
     print "Thank you for taking a moment to fill out our brief questionnaire!";

endif;
?>
</body>
</html>