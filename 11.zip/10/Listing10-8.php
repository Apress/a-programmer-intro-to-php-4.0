<html>
<head>
<title>Listing 10-8</title>
</head>
<body bgcolor="#ffffff" text="#000000" link="#cbda74" vlink="#808040" alink="#808040">
<?
// create the form
$form = "
<form action=\"Listing10-8.php\" method=\"post\">
<input type=\"hidden\" name=\"seenform\" value=\"y\">
<b>Give us some information!</b><br>
Your Name:<br>
<input type=\"text\" name=\"name\" size=\"20\" maxlength=\"20\" value=\"$name\"><br>
Your Email:<br>
<input type=\"text\" name=\"email\" size=\"20\" maxlength=\"40\" value=\"$email\"><br>
<input type=\"submit\" value=\"subscribe!\">
</form>";

// has the form already been filled in?
if ($seenform != "y"):
     print "$form";

// The user has filled out the form. Now verify the information
else :
     $error_flag = "n";
     // ensure that the name variable is not empty
     if ($name == "") :
          print "<font color=\"red\">* You forgot to enter your name!</font> <br>";
          $error_flag = "y";
     endif;
     // ensure that the email variable is not empty
     if ($email == "") :

          print "<font color=\"red\">* You forgot to enter your email!</font> <br>";
          $error_flag = "y";

     else :	
          // convert all email alphabetical characters to lowercase
          $email = strtolower(trim($email));
          // ensure the email address is of valid syntax
          if (! @eregi('^[0-9a-z]+'.
                              '@'.
                              '([0-9a-z-]+\.)+'.
                              '([0-9a-z]){2,4}$', $email)) :

               print "<font color=\"red\">* You entered an invalid email address!</font> <br>";
               $error_flag = "y";
          endif;	
     endif;

     // If the $error_flag has been set, redisplay the form
     if ($error_flag == "y") :
          print "$form";
     else :
          // do something with that user information
          print "You entered valid form information!";
     endif;
endif;
?>
</body>
</html>