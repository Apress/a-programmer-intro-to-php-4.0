<?


// wine for which best years will be displayed
$label = "merlot";

// This function merely makes use of various arrays and a variable variable to return multiple values.
function best_years($label) {

     $merlot = array("1987", "1983", "1977");
     $zinfandel = array("1992", "1990", "1989");

     return $$label;

}
// a list() is used to display the wine's best years.
list ($yr_one, $yr_two, $yr_three) = best_years($label);

print "$label had three particularly remarkable years: $yr_one, $yr_two, and $yr_three.";

?>