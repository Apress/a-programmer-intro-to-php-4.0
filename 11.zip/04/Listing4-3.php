<?

$cost = 456.22;
$limit = 1000.00;

function check_limit($total_cost, $credit_limit) {

     if ($total_cost > $credit_limit) :
          return 0;
     endif;

     return 1;

}

if (check_limit($cost, $limit)) :
// let the user keep shopping
print "Keep shopping!";
else :
print "Please lower your total bill to less than $".$limit."!";
endif;

?>