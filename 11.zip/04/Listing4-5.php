<?

function summation ($count) {

	if ($count != 0) :

		return $count + summation($count-1);

	endif;

}


$sum = summation(10);

print "Summation = $sum";

?>