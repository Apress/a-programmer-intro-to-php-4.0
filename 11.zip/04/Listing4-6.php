<?

// italian welcome message.
function italian() {
     print "Benvenuti al PHP Recipes.";
}

// english welcome message
function english() {
     print "Welcome to PHP Recipes.";
}

// set the user language to italian
$language = "english";

// execute the variable function
$language();

?>