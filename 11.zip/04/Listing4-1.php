<?

function display_footer($site_name) {

         function display_copyright($site_name) {
              print "Copyright &copy ". date("Y"). " $site_name. All Rights Reserved.";
         }

          print "<center>
          <a href = \"\">home</a> | <a href = \"\">recipes</a> | <a href = \"\">events</a><br>
          <a href = \"\">tutorials</a> | <a href = \"\">about</a> | <a href = \"\">contact us</a><br>";

         display_copyright($site_name);

         print "</center>";

}

$site_name = "PHP Recipes";



display_footer($site_name);
display_copyright($site_name);
?>