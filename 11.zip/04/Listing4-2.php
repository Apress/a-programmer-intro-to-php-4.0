<?

$price = 24.99;
$tax = .06;

function calculate_cost($tax, $price) {

     $sales_tax = $tax;
     return $price + ($price * $sales_tax);

}

// Notice how calculate_cost() returns a value.
$total_cost = calculate_cost ($tax, $price);
// round the cost to two decimal places.
$total_cost = round($total_cost, 2);

print "Total cost: $".$total_cost;
// $total_cost = 26.49

?>